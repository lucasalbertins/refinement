#ifndef ROBOCALC_CONTROLLERS_MAINCOMPUTER_H_
#define ROBOCALC_CONTROLLERS_MAINCOMPUTER_H_

#include "SensorVehicle.h"
#include "RoboCalcAPI/Controller.h"
#include "DataTypes.h"

#include "Moving.h"
#include "Detecting.h"

class MainComputer: public robocalc::Controller 
{
public:
	MainComputer(SensorVehicle& _platform) : platform(&_platform){};
	MainComputer() : platform(nullptr){};
	
	~MainComputer() = default;
	
	void Execute()
	{
		moving.execute();
		detecting.execute();
	}
	
	struct Channels
	{
		MainComputer& instance;
		Channels(MainComputer& _instance) : instance(_instance) {}
		
		EventBuffer* tryEmitGas(void* sender, std::tuple<> args)
		{
			if(instance.detecting.canReceiveGas(args))
				instance.detecting.gas_in.trigger(sender, args);
				
			return &instance.detecting.gas_in;
		}
		
		EventBuffer* tryEmitDetect(void* sender, std::tuple<Chemical> args)
		{
			detect_in.trigger(sender, args);
			return &detect_in;
		}
		
		EventBuffer* tryEmitTurn(void* sender, std::tuple<double> args)
		{
			turn_in.trigger(sender, args);
			return &turn_in;
		}
		
		EventBuffer* tryEmitCommand(void* sender, std::tuple<Command> args)
		{
			if(instance.moving.canReceiveCd(args))
				instance.moving.cd_in.trigger(sender, args);
				
			return &instance.moving.cd_in;
		}
		
		struct Detect_t : public EventBuffer
		{
			THREAD_SAFE_ONLY(std::mutex _mutex;)
			std::tuple<Chemical> _args;
			void* _sender = nullptr;
			void* getSender() override
			{
				THREAD_SAFE_ONLY(std::lock_guard<std::mutex> lock{_mutex};)
				return _sender;
			}
			
			void reset() override
			{
				THREAD_SAFE_ONLY(std::lock_guard<std::mutex> lock{_mutex};)
				_sender = nullptr;
			}
			
			void trigger(void* sender, std::tuple<Chemical> args)
			{
				THREAD_SAFE_ONLY(std::lock_guard<std::mutex> lock{_mutex};)
				_args = args;
				_sender = sender;
			}
		} detect_in;
		struct Turn_t : public EventBuffer
		{
			THREAD_SAFE_ONLY(std::mutex _mutex;)
			std::tuple<double> _args;
			void* _sender = nullptr;
			void* getSender() override
			{
				THREAD_SAFE_ONLY(std::lock_guard<std::mutex> lock{_mutex};)
				return _sender;
			}
			
			void reset() override
			{
				THREAD_SAFE_ONLY(std::lock_guard<std::mutex> lock{_mutex};)
				_sender = nullptr;
			}
			
			void trigger(void* sender, std::tuple<double> args)
			{
				THREAD_SAFE_ONLY(std::lock_guard<std::mutex> lock{_mutex};)
				_args = args;
				_sender = sender;
			}
		} turn_in;
	};
	
	Channels channels{*this};
	
	SensorVehicle* platform;
	Moving_StateMachine<MainComputer> moving{*platform, *this, &moving};
	Detecting_StateMachine<MainComputer> detecting{*platform, *this, &detecting};
};

#endif
