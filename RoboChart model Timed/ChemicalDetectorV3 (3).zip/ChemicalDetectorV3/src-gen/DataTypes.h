#ifndef ROBOCALC_DATATYPES_H_
#define ROBOCALC_DATATYPES_H_

#include <string>
#include <set>
#include <tuple>
 
enum Command {
	faster, left, right, back, slower
};
enum Chemical {
	anomaly, danger, innocuous
};
enum Color {
	green, amber, red
};

#endif
