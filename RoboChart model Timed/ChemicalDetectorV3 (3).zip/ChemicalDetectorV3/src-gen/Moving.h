#ifndef ROBOCALC_STATEMACHINES_MOVING_H_
#define ROBOCALC_STATEMACHINES_MOVING_H_

#include "RoboCalcAPI/StateMachine.h"

#ifndef ROBOCALC_THREAD_SAFE
#define THREAD_SAFE_ONLY(x)
#else
#include <mutex>
#define THREAD_SAFE_ONLY(x) x
#endif

#include "SensorVehicle.h"
#include "RoboCalcAPI/Timer.h"
#include "Functions.h"
#include "DataTypes.h"
#include <assert.h>
#include <set>

using namespace robocalc;
using namespace robocalc::functions;

template<typename ControllerType>
class Moving_StateMachine : public StateMachine<SensorVehicle, ControllerType, Moving_StateMachine<ControllerType>>
{
	public:
		ControllerType& controller;
		Command c;
	public:
		class Waiting_State_t : public robocalc::State<ControllerType>
		{
			public:
				explicit Waiting_State_t(ControllerType& _controller, Moving_StateMachine<ControllerType>* topLevel) 
					: robocalc::State<ControllerType>(_controller)
				{
				}
				
				Waiting_State_t() = delete;
			
				void enter() override
				{
				}
				
				void exit() override
				{
				}
				
				void during() override
				{
				}
		};
		
		Waiting_State_t waiting_State;
		
		enum PossibleStates
		{
			s_Waiting,
			j_i1,
			j_j
		} currentState = j_i1; 

	public:
		Moving_StateMachine(SensorVehicle& _platform, ControllerType& _controller, Moving_StateMachine<ControllerType>* topLevel = nullptr) 
			: StateMachine<SensorVehicle, ControllerType, Moving_StateMachine<ControllerType>>(_platform, _controller, topLevel), controller{_controller},
			c(Command::faster),
			waiting_State{_controller, this}
			{};
		Moving_StateMachine() = delete;
		~Moving_StateMachine() = default;
	
	
		bool canReceiveCd(std::tuple<Command> args)
		{
			if(blockedByCd != nullptr)
				if(blockedByCd->getSender() == this)
					return false;
												
			blockedByCd = nullptr;
		
			switch(currentState)
			{
				case s_Waiting:
				{
					return true;
					
					return false;
				}
				default:
				{
					return false;
				}
			}
		}

		EventBuffer* blockedByCd = nullptr;
															
		inline void tryEmitCd(std::tuple<Command> args)
		{
			blockedByCd = controller.channels.tryEmitCd(this, args);
		}
		
		struct Cd_t : public EventBuffer
		{
			THREAD_SAFE_ONLY(std::mutex _mutex;)
			std::tuple<Command> _args;
			void* _sender = nullptr;
			void* getSender() override
			{
				THREAD_SAFE_ONLY(std::lock_guard<std::mutex> lock{_mutex};)
				return _sender;
			}
			
			void reset() override
			{
				THREAD_SAFE_ONLY(std::lock_guard<std::mutex> lock{_mutex};)
				_sender = nullptr;
			}
			
			void trigger(void* sender, std::tuple<Command> args)
			{
				THREAD_SAFE_ONLY(std::lock_guard<std::mutex> lock{_mutex};)
				_args = args;
				_sender = sender;
			}
		} cd_in;
		
	
		void execute() override
		{
			while(tryTransitions());
		
			switch(currentState)
			{
			case s_Waiting:
			{
				waiting_State.during();
				break;
			}
				default:
					break;
			}
		}
	
		bool tryTransitions() override
		{
			switch(currentState)
			{
				case s_Waiting:
				{
					if(cd_in.getSender() != nullptr)
					{
						waiting_State.exit();
						cd_in.reset();
						currentState = j_j;
						return true;	
					}

					break;
				}
				case j_i1:
				{
					
					;
					currentState = s_Waiting;
					waiting_State.enter();
					return true;
				}
				case j_j:
				{
					if(
							(this->c) == (Command::left))
					{
						this->tryEmitTurn(std::tuple<double>{-(90)});;
						waiting_State.enter();
						currentState = s_Waiting;
						return true;
					}
					if(
							(this->c) == (Command::right))
					{
						this->tryEmitTurn(std::tuple<double>{90});;
						waiting_State.enter();
						currentState = s_Waiting;
						return true;
					}
					if(
							(this->c) == (Command::back))
					{
						this->tryEmitTurn(std::tuple<double>{180});;
						waiting_State.enter();
						currentState = s_Waiting;
						return true;
					}
					if(
							(this->c) == (Command::faster))
					{
						this->controller.platform->incr();
						;
						waiting_State.enter();
						currentState = s_Waiting;
						return true;
					}
					if(
							(this->c) == (Command::slower))
					{
						this->controller.platform->decr();
						;
						waiting_State.enter();
						currentState = s_Waiting;
						return true;
					}
					
					break;
				}
				default:
					break;
			}
				
			return false;
		}
};
	
#endif
